import React, { Component } from "react";
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Platform,
  StatusBar,
  Image,
  ScrollView,
  Dimensions
} from "react-native";

export default class PostScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      light_theme: "true"
    };
  }


    render() {
        return (
            <View style={this.state.light_theme ?
              styles.containerLight :
              styles.container}>
              <SafeAreaView style={styles.droidSafeArea} />
              <View style={styles.appTitle}>
                <View style={styles.appIcon}>
                  <Image
                    source={require("../assets/logo.png")}
                  ></Image>
                </View>
                <View style={styles.appTitleTextContainer}>
                  <Text style={this.state.light_theme ?
        styles.appTitleTextLight :
        styles.appTitleText}>App Espectagrama</Text>
                </View>
              </View>
              <View style={styles.postContainer}>
                <ScrollView style={this.state.light_theme ?
                styles.postCardLight :
                styles.postCard}>
                  <Image
                    source={require("../assets/image_1.png")}
                    style={styles.image}
                  ></Image>
                  <View style={styles.postTextContainer}>
                    <Text style={this.state.light_theme ?
                      styles.postTextLight :
                      styles.postText}>
                      {this.props.route.params.post.text}
                    </Text>
                  </View>
                  <View style={styles.actionContainer}>
                    <View style={styles.likeButton}>
                      <Ionicons name={"heart"} size={RFValue(30)} color={"white"} />
                      <Text style={styles.likeText}>12k</Text>
                    </View>
                  </View>
                </ScrollView>
              </View>
            </View>
        );
    }

}